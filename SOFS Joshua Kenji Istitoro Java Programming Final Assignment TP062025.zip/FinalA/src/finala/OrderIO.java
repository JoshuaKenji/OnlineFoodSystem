package finala;

//imports
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class OrderIO {
    public static ArrayList<order> OrderInfo = new ArrayList<order>();
    
    public static void read(){
        try{
            Scanner s = new Scanner(new File("Order.txt"));
            while (s.hasNext()){
                
                String u = s.nextLine();
                String j = s.nextLine();
                String x = s.nextLine();
                double y = Double.parseDouble(s.nextLine());
                String z = s.nextLine();
                int q = Integer.parseInt(s.nextLine());
                
                s.nextLine();
                
                OrderInfo.add(new order(u, j, x,y,z,q));
            }
        }catch (Exception e){
            System.out.println("Error! - reading ");
        }
    }
    
    public static void write(){
        try{
            PrintWriter a = new PrintWriter("Order.txt");
            for(int i=0; i<OrderInfo.size(); i++){
                order c = OrderInfo.get(i);
                a.println(c.getUsername());
                a.println(c.getAddress());
                a.println(c.getItem());
                a.println(c.getPrice());
                a.println(c.getCategory());
                a.println(c.getQuantity());
                a.println();
            }
            a.close();

        }catch (Exception e){
            System.out.println("Error! - writting");
        }
    }
    
    public static order checkOrder(String newOrder){
        order found = null;
        for(int i=0; i<OrderInfo.size(); i++){
            order c = OrderInfo.get(i);
            if(newOrder.equals(c.getItem())){
                found = c;
                break;
            }
        }return found;
    }
}
