package finala;

//imports
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class ItemIO {
    public static ArrayList<item> ItemInfo = new ArrayList<item>();
    public static void read(){
        try{
            Scanner s = new Scanner(new File("ItemInfo.txt"));
            while (s.hasNext()){
                String x = s.nextLine();
                double y = Double.parseDouble(s.nextLine());
                String z = s.nextLine();
                s.nextLine(); //make another paragraph for other new users
                ItemInfo.add(new item(x,y,z));
            }
        }catch (Exception e){
            System.out.println("Error! - reading ");
        }
    }
    public static void write(){
        try{
            PrintWriter a = new PrintWriter("ItemInfo.txt");
            for(int i=0; i<ItemInfo.size(); i++){
                item c = ItemInfo.get(i);
                a.println(c.getItem());
                a.println(c.getPrice());
                a.println(c.getCategory());
                a.println();
            }
            a.close();

        }catch (Exception e){
            System.out.println("Error! - writting");
        }
    }
    public static item checkItem(String newItem){
        item found = null;
        for(int i=0; i<ItemInfo.size(); i++){
            item c = ItemInfo.get(i);
            if(newItem.equals(c.getItem())){
                found = c;
                break;
            }
        }return found;
    }
}
