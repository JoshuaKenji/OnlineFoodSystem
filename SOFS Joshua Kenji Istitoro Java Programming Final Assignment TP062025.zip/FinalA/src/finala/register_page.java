package finala;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class register_page extends JFrame implements ActionListener  {

    JTextField username_field;
    JPasswordField password_field;
    JTextField address_field;
    JTextField phone_field;
    JButton register_button;
    JButton cancel_button;
    
    register_page(){
        
        // ------------------------header--------------------------------
        
        //icon
        ImageIcon image = new ImageIcon(getClass().getResource("SOFSJKI.png"));
        
        // Jlabel = a GUI display area for a string of text, an image, or both
        JLabel SOFS = new JLabel(); //create a label
        SOFS.setText("Spiderman Online Food Service"); //set text of label
        SOFS.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        SOFS.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        SOFS.setBounds(118,10,400,100); //x,y,width,height
        SOFS.setForeground(new Color(237,245,225));
        SOFS.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        // SOFS.setBackground(new Color(55,150,131));
        // SOFS.setOpaque(true);

        //create a logo
        JLabel logo = new JLabel();
        SOFS.setHorizontalTextPosition(JLabel.CENTER);
        SOFS.setVerticalTextPosition(JLabel.CENTER);
        logo.setBounds(77,10,100,100); //x,y,width,height
        logo.setIcon(image);
        
        //Make panel
        JPanel header = new JPanel();
        header.setBackground(new Color(55,150,131));
        header.setSize(500,100);
        //add stuff for the JPanel
        this.add(logo);
        this.add(SOFS);
        
        //---------------------------------------------------------------
        
        //label for username
        JLabel username_label = new JLabel();
        username_label.setText("Create a Username:"); //set text of label
        username_label.setBounds(50, 110, 300, 50); //x,y,width,height
        username_label.setForeground(new Color(237,245,225));
        username_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font

        //input for username
        username_field = new JTextField();
        username_field.setBounds(50, 160, 400, 30); //x,y,width,height
        
        //label for address
        JLabel address_label = new JLabel();
        address_label.setText("Enter your Address:"); //set text of label
        address_label.setBounds(50, 190, 300, 50); //x,y,width,height
        address_label.setForeground(new Color(237,245,225));
        address_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //input for address
        address_field = new JTextField();
        address_field.setBounds(50, 235, 400, 30); //x,y,width,height
        
        //label for password
        JLabel password_label = new JLabel();
        password_label.setText("Create a Password:"); //set text of label
        password_label.setBounds(50, 265, 300, 50); //x,y,width,height
        password_label.setForeground(new Color(237,245,225));
        password_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //input for password
        password_field = new JPasswordField();
        password_field.setBounds(50, 315, 400, 30); //x,y,width,height
        
        //label for phone number
        JLabel phone_label = new JLabel();
        phone_label.setText("Enter your Phone Number:"); //set text of label
        phone_label.setBounds(50, 345, 300, 50); //x,y,width,height
        phone_label.setForeground(new Color(237,245,225));
        phone_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //input for phone number
        phone_field = new JTextField();
        phone_field.setBounds(50, 395, 400, 30); //x,y,width,height
        
        //register button
        register_button = new JButton();
        register_button.setText("Register");
        register_button.setBounds(120,460,100,50);
        register_button.addActionListener(this);
        register_button.setFont(new Font("Helvetica",Font.PLAIN,20));
        register_button.setForeground(new Color(5,56,107));
        register_button.setBackground(new Color(237,245,225));
        register_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //cancel button
        cancel_button = new JButton();
        cancel_button.setBounds(270,460,100,50);
        cancel_button.addActionListener(this);
        cancel_button.setText("Cancel");
        cancel_button.setFont(new Font("Helvetica",Font.PLAIN,20));
        cancel_button.setForeground(new Color(5,56,107));
        cancel_button.setBackground(new Color(237,245,225));
        cancel_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //--------------------------window---------------------------------
        this.setTitle("SOFS register");
        this.setSize(500,600); //sets the x-dimension, sets y dimension
        this.getContentPane().setBackground(new Color(92,219,149)); //change background color to custom (R,G,B)
        this.setResizable(false); //window not resizable
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close when exited (release RAM)
        this.setLocation(600,200);
        this.setLayout(null); //setting position
        //add stuff for the JFrame
        this.add(header);
        this.add(username_label);
        this.add(username_field);
        this.add(address_label);
        this.add(address_field);
        this.add(password_label);
        this.add(password_field);
        this.add(phone_label);
        this.add(phone_field);
        this.add(register_button);
        this.add(cancel_button);
        
        this.setVisible(true);
        //---------------------------------------------------------------
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancel_button){
            this.dispose();
//            setVisible(false);
            new homepage();
        }else if (e.getSource() == register_button){
            if(username_field.getText().isEmpty() || address_field.getText().isEmpty() || password_field.getText().isEmpty() || phone_field.getText().isEmpty() ){
                JOptionPane.showMessageDialog(null,"Empty Fields, Please Fill All Fields!");
            }else{
                String username = username_field.getText();
                String address = address_field.getText();
                String password = password_field.getText();
                String phone_number = phone_field.getText();
                
                //validate for redundant username
                customer found = DataIO.checkUsername(username);
                if (found == null){
                    DataIO.CustomerInfo.add(new customer(username,address,password,phone_number));
                    DataIO.write();
                    this.dispose();
//                    setVisible(false);
                    JOptionPane.showMessageDialog(null,"Account Registered!");
                    new login_page();
                }else{
                    JOptionPane.showMessageDialog(null,"Username Exist, be more creative!");
                }
            }
        }
    }
}    
