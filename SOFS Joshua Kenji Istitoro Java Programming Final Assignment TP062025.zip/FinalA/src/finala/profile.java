package finala;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class profile extends JFrame implements ActionListener {
    
        JButton back_button;
        JButton change_username;
        JButton change_password;
    
    profile(){
        
        // ------------------------header--------------------------------
        
        //icon
        ImageIcon image = new ImageIcon(getClass().getResource("SOFSJKI.png"));
        
        // Jlabel = a GUI display area for a string of text, an image, or both
        JLabel SOFS = new JLabel(); //create a label
        SOFS.setText("Spiderman Online Food Service"); //set text of label
        SOFS.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        SOFS.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        SOFS.setBounds(118,10,400,100); //x,y,width,height
        SOFS.setForeground(new Color(237,245,225));
        SOFS.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        // SOFS.setBackground(new Color(55,150,131));
        // SOFS.setOpaque(true);

        //create a logo
        JLabel logo = new JLabel();
        SOFS.setHorizontalTextPosition(JLabel.CENTER);
        SOFS.setVerticalTextPosition(JLabel.CENTER);
        logo.setBounds(77,10,100,100); //x,y,width,height
        logo.setIcon(image);
        
        //Make panel
        JPanel header = new JPanel();
        header.setBackground(new Color(55,150,131));
        header.setSize(500,100);
        //add stuff for the JPanel
        this.add(logo);
        this.add(SOFS);
        
        //---------------------------------------------------------------
        
        //buttons
        
        //signout button
        back_button = new JButton();
        back_button.setBounds(15,110,85,35); //x,y,width,height
        back_button.addActionListener(this);
        back_button.setText("BACK");
        back_button.setFont(new Font("Helvetica",Font.BOLD,15));
        back_button.setForeground(new Color(237,245,225));
        back_button.setBackground(new Color(55,150,131));
        back_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        

        //manage foods button
        change_username = new JButton();
        change_username.setBounds(160,240,170,50); //x,y,width,height
        change_username.addActionListener(this);
        change_username.setText("Change Username");
        change_username.setFont(new Font("Helvetica",Font.BOLD,17));
        change_username.setForeground(new Color(237,245,225));
        change_username.setBackground(new Color(55,150,131));
        change_username.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        
        //view orders button
        change_password = new JButton();
        change_password.setBounds(160,310,170,50); //x,y,width,height
        change_password.addActionListener(this);
        change_password.setText("Change Password");
        change_password.setFont(new Font("Helvetica",Font.BOLD,17));
        change_password.setForeground(new Color(237,245,225));
        change_password.setBackground(new Color(55,150,131));
        change_password.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        
        //---------------------------------------------------------------
        
        //Jframe or window
            this.setTitle("SOFS admin/staff homepage");
            this.setSize(500,600); //sets the x-dimension, sets y dimension
            this.getContentPane().setBackground(new Color(237,245,225)); //change background color to custom (R,G,B)
            this.setResizable(false); //window not resizable
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close when exited (release RAM)
            this.setLocation(600,200);
            this.setLayout(null); //setting position
            //add stuff for the JFrame
            this.add(header);
            this.add(back_button);
            this.add(change_username);
            this.add(change_password);
            this.setVisible(true);
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == back_button){
            new homepage_admin();
            this.dispose();
        }else if (e.getSource() == change_username){
            String input = JOptionPane.showInputDialog("Enter new username:");
            admin found = AdminIO.checkAdmin(input);
            if(found != null){
                try{
                   throw new Exception(); 
                }catch(Exception ex){

                }
            }
            FinalA.admin.setUsername(input);
            AdminIO.write();
                
        }else if (e.getSource() == change_password){
            String input = JOptionPane.showInputDialog("Enter new password:");
            String password = input;
            if(FinalA.admin.getPassword() == password){
                try{
                   throw new Exception(); 
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null,"Error!");
                }
            }
            FinalA.admin.setPassword(password);
            AdminIO.write();
        } 
    }
    
}
