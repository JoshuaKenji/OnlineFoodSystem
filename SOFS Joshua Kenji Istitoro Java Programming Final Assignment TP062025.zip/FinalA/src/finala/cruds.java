package finala;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

public class cruds {
    
    cruds(){
        // create JFrame and JTable
        JFrame frame = new JFrame();
        JTable table = new JTable(); 
        
        String allData[][] = new String[ItemIO.ItemInfo.size()][3];
        for(int i=0; i<ItemIO.ItemInfo.size();i++){
            String rowData[] = new String[3];
            item found = ItemIO.ItemInfo.get(i);
//            rowData[0] = String.valueOf(found.foodId);
            rowData[0] = found.getItem();
            rowData[1] = String.valueOf(found.getPrice());
            rowData[2] = found.getCategory();
            allData[i] = rowData;
            

            //model.addRow(rowData);
        }
        
        
        
        // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Food/Drinks","Price","Category"};
        DefaultTableModel model = new DefaultTableModel(allData,columns);
        model.setColumnIdentifiers(columns);
        
        
        
        // set the model to the table
        table.setModel(model);
        
        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(new Color(237,245,225));
        table.setForeground(new Color(55,150,131));
        Font font = new Font("Helvetica",Font.BOLD,16);
        table.setFont(font);
        table.setRowHeight(30);
        
        //sorter
        TableRowSorter sorter = new TableRowSorter(model);
        table.setRowSorter(sorter);
        
        JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(100, 50));
        table.getTableHeader().setBackground(new Color(55,150,131));
        table.getTableHeader().setForeground(new Color(237,245,225));
        Font font2 = new Font("Helvetica",Font.BOLD,18);
        table.getTableHeader().setFont(font2);
        
        
        //labels
        JLabel first_label = new JLabel(); 
        first_label.setText("Item's Name:");
        first_label.setForeground(new Color(55,150,131));
        first_label.setFont(new Font("Helvetica",Font.BOLD,13));
        first_label.setBounds(20, 310, 100, 25);
        
        JLabel second_label = new JLabel(); 
        second_label.setText("Price:");
        second_label.setForeground(new Color(55,150,131));
        second_label.setFont(new Font("Helvetica",Font.BOLD,13));
        second_label.setBounds(20, 355, 100, 25);
        
        JLabel third_label = new JLabel(); 
        third_label.setText("Category:");
        third_label.setForeground(new Color(55,150,131));
        third_label.setFont(new Font("Helvetica",Font.BOLD,13));
        third_label.setBounds(20, 400, 100, 25);
        
        
        // TextFields
        JTextField textFood = new JTextField();
        JTextField textPrice = new JTextField();
        String[] categories = {"rice","noodle","appetizer","desert","drink"};
        JComboBox textCategory = new JComboBox(categories);
        textCategory.setBackground(Color.WHITE);
        
        textFood.setBounds(140, 310, 100, 25);
        textPrice.setBounds(140, 355, 100, 25);
        textCategory.setBounds(140, 400, 100, 25);
        
        // Buttons
        JButton btnAdd = new JButton("Add");
        JButton btnDelete = new JButton("Delete");
        JButton btnUpdate = new JButton("Update");  
        JButton btnBack = new JButton("Back"); 
        
        btnAdd.setFont(new Font("Helvetica",Font.BOLD,13));
        btnAdd.setForeground(new Color(237,245,225));
        btnAdd.setBackground(new Color(55,150,131));
        btnAdd.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        btnDelete.setFont(new Font("Helvetica",Font.BOLD,13));
        btnDelete.setForeground(new Color(237,245,225));
        btnDelete.setBackground(new Color(55,150,131));
        btnDelete.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        btnUpdate.setFont(new Font("Helvetica",Font.BOLD,13));
        btnUpdate.setForeground(new Color(237,245,225));
        btnUpdate.setBackground(new Color(55,150,131));
        btnUpdate.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        btnBack.setFont(new Font("Helvetica",Font.BOLD,13));
        btnBack.setForeground(new Color(237,245,225));
        btnBack.setBackground(new Color(55,150,131));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        btnAdd.setBounds(20, 510, 100, 25);
        btnUpdate.setBounds(140, 510, 100, 25);
        btnDelete.setBounds(260, 510, 100, 25);
        btnBack.setBounds(380, 510, 100, 25);
        
        //JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 0, 500, 300);
        pane.getViewport().setBackground(new Color(237,245,225));
        frame.setTitle("SOFS manage food");
        frame.getContentPane().setBackground(new Color(237,245,225)); //change background color to custom (R,G,B)
        frame.setResizable(false);
        frame.setLocation(600,200);
        
        frame.setLayout(null);
        
        frame.add(pane);
        
        //add text
        frame.add(first_label);
        frame.add(second_label);
        frame.add(third_label);
        
        // add fields
        frame.add(textFood);
        frame.add(textPrice);
        frame.add(textCategory);
    
        // add buttons
        frame.add(btnAdd);
        frame.add(btnDelete);
        frame.add(btnUpdate);
        frame.add(btnBack);
        
        // create an array of objects to set the row data
        Object[] row = new Object[4];
        
        //
        btnBack.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent bk){
                if (bk.getSource() == btnBack){
                    new homepage_admin();
                    frame.dispose();
                }
            }
        });
        
        // add button
        btnAdd.addActionListener(new ActionListener(){
            
            
            @Override
            public void actionPerformed(ActionEvent e) {
             
                try{
    //                int a = Integer.parseInt(textId.getText());
                    String b = textFood.getText();
                    double c = Double.parseDouble(textPrice.getText());
                    String d = textCategory.getSelectedItem().toString();

    //                row[0] = textId.getText();
                    row[0] = textFood.getText();
                    row[1] = textPrice.getText();
                    row[2] = textCategory.getSelectedItem().toString();

                    // add row to the model
                    model.addRow(row);
                    item foodview = ItemIO.checkItem(b);
                    if (foodview == null){
                        ItemIO.ItemInfo.add(new item(b,c,d));
                        ItemIO.write();
                    }
                }catch(Exception add){
                    JOptionPane.showMessageDialog(null,"Invalid! Try Again");
                }
                }
                
            }
        );
        
        // button remove row
        btnDelete.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
            
//                int a = Integer.parseInt(textId.getText());
                String b = textFood.getText();
                double c = Double.parseDouble(textPrice.getText());
                String d = textCategory.getSelectedItem().toString();
                
                
                // i = the index of the selected row
                int i = table.getSelectedRow();
                if(i >= 0){
                    
                    // remove a row from jtable
                    String view = table.getModel().getValueAt(i, 0).toString();

                    for (int j = 0; j < ItemIO.ItemInfo.size(); j++) {
                        item found = ItemIO.ItemInfo.get(j);
                        if (found.getItem().equals(view)) {
                            FinalA.product = found;
                        }
                    }
                    ItemIO.ItemInfo.remove(FinalA.product);
                    model.removeRow(i);
                    ItemIO.write();
                    
                } else{
                    System.out.println("Delete Error");
                }
            }
        });
        
        // get selected row data From table to textfields 
        table.addMouseListener(new MouseAdapter(){
        
        @Override
        public void mouseClicked(MouseEvent e){
            
            // i = the index of the selected row
            int i = table.getSelectedRow();
            
//            textId.setText(model.getValueAt(i, 0).toString());
            textFood.setText(model.getValueAt(i, 0).toString());
            textPrice.setText(model.getValueAt(i, 1).toString());
            textCategory.setSelectedItem(model.getValueAt(i, 2).toString());
        }
        });
        
        // update button
        btnUpdate.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
             
                try{
                    String b = textFood.getText();
                    double c = Double.parseDouble(textPrice.getText());
                    String d = textCategory.getSelectedItem().toString();

                    int row = table.getSelectedRow();
                    String view = table.getModel().getValueAt(row, 0).toString();

                    for (int i = 0; i < ItemIO.ItemInfo.size();i++){
                        item found = ItemIO.ItemInfo.get(i);
                        if (found.getItem().equals(view)){
                            FinalA.product = found;
                        }
                    }
                    FinalA.product.setItem(b);
                    FinalA.product.setPrice(c);
                    FinalA.product.setCategory(d);
                    ItemIO.write();

                    // i = the index of the selected row
                    int i = table.getSelectedRow();

                    if(i >= 0) 
                    {
    //                   model.setValueAt(textId.getText(), i, 0);
                       model.setValueAt(textFood.getText(), i, 0);
                       model.setValueAt(textPrice.getText(), i, 1);
                       model.setValueAt(textCategory.getSelectedItem().toString(), i, 2);
                    }
                    else{
                        System.out.println("Update Error");
                    }
                }catch(Exception up){
                    JOptionPane.showMessageDialog(null,"Invalid! Try Again");
                }
            }
        });

        frame.setSize(500,600);
//        frame.setSize(900,400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
