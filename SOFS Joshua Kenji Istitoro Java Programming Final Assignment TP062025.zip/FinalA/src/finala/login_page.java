package finala;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login_page extends JFrame implements ActionListener{
    
    JTextField username_field;
    JPasswordField password_field;
    JButton submit_button;
    JButton cancel_button;
    
    
    login_page(){
        
        //icon
        ImageIcon image = new ImageIcon(getClass().getResource("SOFSJKI.png"));
        
        
        // Jlabel = a GUI display area for a string of text, an image, or both
        JLabel SOFS = new JLabel(); //create a label
        SOFS.setText("Spiderman Online Food Service"); //set text of label
        SOFS.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        SOFS.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        SOFS.setBounds(118,10,400,100); //x,y,width,height
        SOFS.setForeground(new Color(237,245,225));
        SOFS.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        // SOFS.setBackground(new Color(55,150,131));
        // SOFS.setOpaque(true);

        //create a logo
        JLabel logo = new JLabel();
        SOFS.setHorizontalTextPosition(JLabel.CENTER);
        SOFS.setVerticalTextPosition(JLabel.CENTER);
        logo.setBounds(77,10,100,100); //x,y,width,height
        logo.setIcon(image);
        
        //Make panel
        JPanel header = new JPanel();
        header.setBackground(new Color(55,150,131));
        header.setSize(500,100);
        //add stuff for the JPanel
        this.add(logo);
        this.add(SOFS);
        
        //label for username
        JLabel username_label = new JLabel();
        username_label.setText("Username:"); //set text of label
        username_label.setBounds(50, 150, 200, 50); //x,y,width,height
        username_label.setForeground(new Color(237,245,225));
        username_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //input for username
        username_field = new JTextField();
//        SOFS.setHorizontalTextPosition(JLabel.CENTER);
//        SOFS.setVerticalTextPosition(JLabel.CENTER);
        username_field.setBounds(50, 200, 400, 30); //x,y,width,height
        
        //label for password
        JLabel password_label = new JLabel();
        password_label.setText("Password:"); //set text of label
        password_label.setBounds(50, 250, 200, 50); //x,y,width,height
        password_label.setForeground(new Color(237,245,225));
        password_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //input for pass
        password_field = new JPasswordField();
        password_field.setBounds(50, 300, 400, 30); //x,y,width,height
        
        //submit button
        submit_button = new JButton();
        submit_button.setBounds(200,365,100,50);
        submit_button.addActionListener(this);
        submit_button.setText("Login");
        submit_button.setFont(new Font("Helvetica",Font.BOLD,20));
        submit_button.setForeground(new Color(237,245,225));
        submit_button.setBackground(new Color(55,150,131));
        submit_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        //cancel button
        cancel_button = new JButton();
        cancel_button.setBounds(200,450,100,50);
        cancel_button.addActionListener(this);
        cancel_button.setText("Cancel");
        cancel_button.setFont(new Font("Helvetica",Font.BOLD,20));
        cancel_button.setForeground(new Color(237,245,225));
        cancel_button.setBackground(new Color(55,150,131));
        cancel_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        
        // window
        this.setTitle("SOFS login");
        this.setSize(500,600); //sets the x-dimension, sets y dimension
        this.getContentPane().setBackground(new Color(92,219,149)); //change background color to custom (R,G,B)
        this.setResizable(false); //window not resizable
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close when exited (release RAM)
        this.setLocation(600,200);
        this.setLayout(null); //setting position
        //add stuff for the JFrame
        this.add(header);
        this.add(username_label);
        this.add(username_field);
        this.add(password_label);
        this.add(password_field);
        this.add(submit_button);
        this.add(cancel_button);
        this.setVisible(true);
}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancel_button){
            new homepage();
            this.dispose();
            setVisible(false);
        }else if (e.getSource() == submit_button){
            String a = username_field.getText();
            String b = password_field.getText();

            try {
                customer found = DataIO.checkUsername(a);
                if (found != null) {
                    if (!b.equals(found.getPassword())) {
                        throw new Exception();
                    } else {
                        FinalA.login = found;
                        new homepage_user();
                        this.setVisible(false);
                    }
                } else {
                    throw new Exception();
                }
            } catch (Exception ea) {
                JOptionPane.showMessageDialog(null,"User not found, please try again!");
            }
        }
    }
    
}
