package finala;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

public class view_menu {
    
    view_menu(){
        // create JFrame and JTable
        JFrame frame = new JFrame();
        JTable table = new JTable(); 
        
        String allData[][] = new String[ItemIO.ItemInfo.size()][3];
        for(int i=0; i<ItemIO.ItemInfo.size();i++){
            String rowData[] = new String[3];
            item found = ItemIO.ItemInfo.get(i);
            
            rowData[0] = found.getItem();
            rowData[1] = String.valueOf(found.getPrice());
            rowData[2] = found.getCategory();
            allData[i] = rowData;
            

            //model.addRow(rowData);
        }
        
        
        
        // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Food/Drinks","Price","Category"};
        DefaultTableModel model = new DefaultTableModel(allData,columns);
        model.setColumnIdentifiers(columns);
        
        // set the model to the table
        table.setModel(model);
        
        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(new Color(237,245,225));
        table.setForeground(new Color(55,150,131));
        Font font = new Font("Helvetica",Font.BOLD,16);
        table.setFont(font);
        table.setRowHeight(30);
   
        //sorter
        TableRowSorter sorter = new TableRowSorter(model);
        table.setRowSorter(sorter);
        
        JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(100, 50));
        table.getTableHeader().setBackground(new Color(55,150,131));
        table.getTableHeader().setForeground(new Color(237,245,225));
        Font font2 = new Font("Helvetica",Font.BOLD,18);
        table.getTableHeader().setFont(font2);
        
        
        //labels
        JLabel first_label = new JLabel(); 
        first_label.setText("Item's Name:");
        first_label.setForeground(new Color(55,150,131));
        first_label.setFont(new Font("Helvetica",Font.BOLD,15));
        first_label.setBounds(20, 310, 100, 25);
        
        JLabel second_label = new JLabel(); 
        second_label.setText("Price:");
        second_label.setForeground(new Color(55,150,131));
        second_label.setFont(new Font("Helvetica",Font.BOLD,15));
        second_label.setBounds(20, 355, 100, 25);
        
        JLabel third_label = new JLabel(); 
        third_label.setText("Category:");
        third_label.setForeground(new Color(55,150,131));
        third_label.setFont(new Font("Helvetica",Font.BOLD,15));
        third_label.setBounds(20, 400, 100, 25);
        
        JLabel fourth_label = new JLabel(); 
        fourth_label.setText("Quantity:");
        fourth_label.setForeground(new Color(55,150,131));
        fourth_label.setFont(new Font("Helvetica",Font.BOLD,15));
        fourth_label.setBounds(20, 445, 100, 25);
        
        
        // TextFields
//        JTextField textFood = new JTextField();
        JLabel textFood = new JLabel();
        textFood.setBounds(140, 310, 150, 25);
        textFood.setForeground(Color.BLACK);
        textFood.setFont(new Font("Helvetica",Font.BOLD,15));
        
//        JTextField textPrice = new JTextField();
        JLabel textPrice = new JLabel();
        textPrice.setBounds(140, 355, 100, 25);
        textPrice.setForeground(Color.BLACK); 
        textPrice.setFont(new Font("Helvetica",Font.BOLD,15));
        
        JLabel textCategory = new JLabel();
        textCategory.setBounds(140, 400, 100, 25);
        
//        String[] categories = {"rice","noodle","appetizer","desert","drink"};
//        JComboBox textCategory = new JComboBox(categories);
//        textCategory.setBackground(Color.WHITE);
        textCategory.setBounds(140, 400, 100, 25);
        textCategory.setForeground(Color.BLACK);
        textCategory.setFont(new Font("Helvetica",Font.BOLD,15));
        
        // Quantity input
        JTextField quantity_field = new JTextField();
        quantity_field.setBounds(140, 445, 100, 25);
        
        // Buttons
        JButton btnAdd = new JButton("Add To Cart");
        JButton btnBack = new JButton("Back");
        JButton btnNext = new JButton("View Cart"); 
        btnNext.setBounds(380, 420, 100, 25);
        btnAdd.setBounds(380, 465, 100, 25);
        btnBack.setBounds(380, 510, 100, 25);
        
        btnAdd.setFont(new Font("Helvetica",Font.BOLD,13));
        btnAdd.setForeground(new Color(237,245,225));
        btnAdd.setBackground(new Color(55,150,131));
        btnAdd.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        btnBack.setFont(new Font("Helvetica",Font.BOLD,13));
        btnBack.setForeground(new Color(237,245,225));
        btnBack.setBackground(new Color(55,150,131));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        btnNext.setFont(new Font("Helvetica",Font.BOLD,13));
        btnNext.setForeground(new Color(237,245,225));
        btnNext.setBackground(new Color(55,150,131));
        btnNext.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));

        
        //JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 0, 500, 300);
        pane.getViewport().setBackground(new Color(237,245,225));
        frame.setTitle("SOFS order food");
        frame.getContentPane().setBackground(new Color(237,245,225)); //change background color to custom (R,G,B)
        frame.setResizable(false);
        frame.setLocation(600,200);
        
        frame.setLayout(null);

        frame.add(pane);
        
        //add text
        frame.add(first_label);
        frame.add(second_label);
        frame.add(third_label);
        frame.add(fourth_label);
        
        // add fields
        frame.add(textFood);
        frame.add(textPrice);
        frame.add(textCategory);
        frame.add(quantity_field);
    
        // add buttons
        frame.add(btnAdd);
        frame.add(btnBack);
        frame.add(btnNext);
        // create an array of objects to set the row data
        Object[] row = new Object[4];
        
        // back button
        btnBack.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent bk){
                if (bk.getSource() == btnBack){
                    new homepage_user();
                    frame.dispose();
                }
            }
        });
        
        // view cart or "next" button
        btnNext.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent vc){
                if (vc.getSource() == btnNext){
                    new cart();
                    frame.dispose();
                }
            }
        });
        
//        // add button
        btnAdd.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

//            int a = Integer.parseInt(textId.getText());
//            private static AtomicInteger ID_GENERATOR = new AtomicInteger(1000);
//            public User(String fN, String sn, String g, String a) {
//            customerID = ID_GENERATOR.getAndIncrement();
            try{
                String un = FinalA.login.getUsername();
                String ad = FinalA.login.getAddress();
                String a = textFood.getText();
                double b = Double.parseDouble(textPrice.getText());
                String c = textCategory.getText();
                int q = Integer.parseInt(quantity_field.getText());
//                double total = b*q;
//                System.out.println(total);

                    OrderIO.OrderInfo.add(new order(un,ad,a,b,c,q));
                    OrderIO.write();
                    JOptionPane.showMessageDialog(null,"Added to Cart!");
//                     new cart();
            }catch(Exception O){
                JOptionPane.showMessageDialog(null,"Add Something First!");
            }
}
        });
        
        // get selected row data From table to textfields 
        table.addMouseListener(new MouseAdapter(){
        
        @Override
        public void mouseClicked(MouseEvent e){
            
            // i = the index of the selected row
            int i = table.getSelectedRow();
            
            textFood.setText(model.getValueAt(i, 0).toString());
            textPrice.setText(model.getValueAt(i, 1).toString());
//            textCategory.setSelectedItem(model.getValueAt(i, 2).toString());
            textCategory.setText(model.getValueAt(i, 2).toString());
        }
        });
        

        frame.setSize(500,600);
//        frame.setSize(900,400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
