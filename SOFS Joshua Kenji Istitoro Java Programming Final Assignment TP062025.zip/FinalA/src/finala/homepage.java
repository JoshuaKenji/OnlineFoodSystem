package finala;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

//public class homepage extends JFrame{
public class homepage extends JFrame implements ActionListener{
    //J Frame = a GUI window to add components
    
    JButton login_button;
    JButton register_button;
    JButton Alogin_button;
    JButton exit_button;
    
    homepage(){

        //icon
        ImageIcon image = new ImageIcon(getClass().getResource("SOFSJKI.png"));
        
        
        // Jlabel = a GUI display area for a string of text, an image, or both
        JLabel SOFS = new JLabel(); //create a label
        SOFS.setText("Spiderman Online Food Service"); //set text of label
        SOFS.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        SOFS.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        SOFS.setBounds(118,10,400,100); //x,y,width,height
        SOFS.setForeground(new Color(237,245,225));
        SOFS.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        // SOFS.setBackground(new Color(55,150,131));
        // SOFS.setOpaque(true);

        //create a logo
        JLabel logo = new JLabel();
        SOFS.setHorizontalTextPosition(JLabel.CENTER);
        SOFS.setVerticalTextPosition(JLabel.CENTER);
        logo.setBounds(77,10,100,100); //x,y,width,height
        logo.setIcon(image);
        
        
        //Make panel
        JPanel header = new JPanel();
        header.setBackground(new Color(55,150,131));
        header.setSize(500,100);
        //add stuff for the JPanel
        this.add(logo);
        this.add(SOFS);
       
        
        //buttons
//------------------------------------
        //login button
        login_button = new JButton();
        login_button.setBounds(175,180,150,50);
        login_button.addActionListener(this);
        login_button.setText("Login");
        login_button.setFont(new Font("Helvetica",Font.BOLD,20));
        login_button.setForeground(new Color(237,245,225));
        login_button.setBackground(new Color(55,150,131));
        login_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        //register button
        register_button = new JButton();
        register_button.setBounds(175,250,150,50);
        register_button.addActionListener(this);
        register_button.setText("Register");
        register_button.setFont(new Font("Helvetica",Font.BOLD,20));
        register_button.setForeground(new Color(237,245,225));
        register_button.setBackground(new Color(55,150,131));
        register_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        //admin login button
        Alogin_button = new JButton();
        Alogin_button.setBounds(175,320,150,50);
        Alogin_button.addActionListener(this);
        Alogin_button.setText("Staff Login");
        Alogin_button.setFont(new Font("Helvetica",Font.BOLD,20));
        Alogin_button.setForeground(new Color(237,245,225));
        Alogin_button.setBackground(new Color(55,150,131));
        Alogin_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        //exit button
        exit_button = new JButton();
        exit_button.setBounds(175,390,150,50);
        exit_button.addActionListener(this);
        exit_button.setText("Exit");
        exit_button.setFont(new Font("Helvetica",Font.BOLD,20));
        exit_button.setForeground(new Color(237,245,225));
        exit_button.setBackground(new Color(55,150,131));
        exit_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        //make a window or frame
        //JFrame this = new JFrame();
        this.setTitle("SOFS app");
        this.setSize(500,600); //sets the x-dimension, sets y dimension
        this.getContentPane().setBackground(new Color(92,219,149)); //change background color to custom (R,G,B)
        this.setResizable(false); //window not resizable
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close when exited (release RAM)
        this.setLocation(600,200);
        this.setLayout(null); //setting position
        //add stuff for the JFrame
        this.add(header);
        this.add(login_button);
        this.add(register_button);
        this.add(Alogin_button);
        this.add(exit_button);

        
        this.setVisible(true); //make "this" visible 
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == exit_button){
            System.exit(0);
        }else if(e.getSource() == login_button){
            this.dispose();
            new login_page();
            setVisible(false);
        }else if(e.getSource() == Alogin_button){
            this.dispose();
            new admin_login();
            setVisible(false);
        }else if(e.getSource() == register_button){
            this.dispose();
            new register_page();
        }

        
        
    }
}
