package finala;

//imports
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class DataIO {
    public static ArrayList<customer> CustomerInfo = new ArrayList<customer>();
    public static void read(){
        try{
            Scanner s = new Scanner(new File("CustomerInfo.txt"));
            while (s.hasNext()){
                String username = s.nextLine();
                String address = s.nextLine();
                String password = s.nextLine();
                String phone_number = s.nextLine();
                s.nextLine(); //make another paragraph for other new users
                CustomerInfo.add(new customer(username,address,password,phone_number));
            }
        }catch (Exception e){
            System.out.println("Error! - reading ");
        }
    }
    public static void write(){
        try{
            PrintWriter a = new PrintWriter("CustomerInfo.txt");
            for(int i=0; i<CustomerInfo.size(); i++){
                customer c = CustomerInfo.get(i);
                a.println(c.getUsername());
                a.println(c.getAddress());
                a.println(c.getPassword());
                a.println(c.getAddress());
                a.println();
            }
            a.close();

        }catch (Exception e){
            System.out.println("Error! - writting");
        }
    }
    public static customer checkUsername(String newUsername){
        customer found = null;
        for(int i=0; i<CustomerInfo.size(); i++){
            customer c = CustomerInfo.get(i);
            if(newUsername.equals(c.getUsername())){
                found = c;
                break;
            }
        }return found;
    }
}
