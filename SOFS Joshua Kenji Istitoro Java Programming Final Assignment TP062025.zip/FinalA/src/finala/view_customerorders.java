package finala;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

public class view_customerorders {

    view_customerorders() {

        JFrame frame = new JFrame();
        JTable table = new JTable();

        String allData[][] = new String[OrderIO.OrderInfo.size()][6];
        for (int i = 0; i < OrderIO.OrderInfo.size(); i++) {
            String rowData[] = new String[6];
            order found = OrderIO.OrderInfo.get(i);
            rowData[0] = found.getUsername();
            rowData[1] = found.getAddress();
            rowData[2] = found.getItem();
            rowData[3] = String.valueOf(found.getQuantity());
            rowData[4] = String.valueOf(found.getPrice());
            rowData[5] = String.valueOf(found.getPrice()*found.getQuantity());
            allData[i] = rowData;
          
        }
        
        // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Username", "Address", "Food Name", "Quantity", "Price Per Item", "Total Price(RM)"};
        DefaultTableModel model = new DefaultTableModel(allData, columns);
        model.setColumnIdentifiers(columns);

        // set the model to the table
        table.setModel(model);
        
        //sorter
        TableRowSorter sorter = new TableRowSorter(model);
        table.setRowSorter(sorter);
        
        //header
        JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(100, 50));
        table.getTableHeader().setBackground(new Color(55,150,131));
        table.getTableHeader().setForeground(new Color(237,245,225));
        Font font2 = new Font("Helvetica",Font.BOLD,18);
        table.getTableHeader().setFont(font2);
        
        
//        table.getBackground();
        table.setPreferredScrollableViewportSize(new Dimension(1200, 500));
        table.setBackground(new Color(237,245,225));
        table.setForeground(new Color(55,150,131));
        Font font = new Font("Helvetica",Font.BOLD,16);
        table.setFont(font);
        table.setRowHeight(30);
        
        //order completed button
        JButton btncomp = new JButton("Completed");
        btncomp.setBounds(900, 500, 100, 25);
        btncomp.setFont(new Font("Helvetica",Font.BOLD,13));
        btncomp.setForeground(new Color(237,245,225));
        btncomp.setBackground(new Color(55,150,131));
        btncomp.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));

        //back button
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(1050, 500, 100, 25);
        btnBack.setFont(new Font("Helvetica",Font.BOLD,13));
        btnBack.setForeground(new Color(237,245,225));
        btnBack.setBackground(new Color(55,150,131));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));

        // create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 0, 1200, 450);
        pane.getViewport().setBackground(new Color(237,245,225));

        frame.setLayout(null);
        frame.add(pane);
        frame.setTitle("SOFS view orders");
        frame.getContentPane().setBackground(new Color(237,245,225));
        frame.setResizable(false);
        frame.add(btnBack);
        frame.add(btncomp);

        // create an array of objects to set the row data
        Object[] row = new Object[4];

        btnBack.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == btnBack) {
                    frame.dispose();
                    new homepage_admin();
                }
            }
        });
        
        
        // button completed (delete)
        btncomp.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                
                // getting index (i) of the selected row
                int i = table.getSelectedRow();
                if(i >= 0){
                    
                    // remove/"complete" a row from jtable
                    String view = table.getModel().getValueAt(i, 2).toString();

                    for (int j = 0; j < OrderIO.OrderInfo.size(); j++) {
                        order found = OrderIO.OrderInfo.get(j);
                        if (found.getItem().equals(view)) {
                            FinalA.order = found;
                        }
                    }
                    OrderIO.OrderInfo.remove(FinalA.order);
                    model.removeRow(i);
                    OrderIO.write();
                    
                } else{
                    System.out.println("Delete Error");
                }
            }
        });


        frame.setSize(1200, 600);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
}

