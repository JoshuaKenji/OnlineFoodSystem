package finala;

public class FinalA {
//    public static homepage no1 = new homepage();
//    public static homepage_user no2 = new homepage_user();
//    public static homepage_admin no3 = new homepage_admin();
//    public static add_items no4 = new add_items();
    public static customer login;
    public static item product;
    public static admin admin;
    public static order order;
    
    public static void main(String[] args) {
        
        DataIO.read();
        AdminIO.read();
        ItemIO.read();
        OrderIO.read();
        new homepage();
//    public static homepage no1 = new homepage();

    }
}
