package finala;
public class item {
    private String item;

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    private double price;
    private String category;

    public item(String food, double money, String topic) {
        this.item = food;
        this.price = money;
        this.category = topic;
    }
}
