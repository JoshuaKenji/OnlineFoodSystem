package finala;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class homepage_admin extends JFrame implements ActionListener {

    JButton signout_button;
    JButton exit_button;
    JButton manage_button;
    JButton modify_button;
    JButton foods_button;
    JButton vieworders_button;
    JButton profile_button;
    
    homepage_admin(){
    
        // ------------------------header--------------------------------
        
        //icon
        ImageIcon image = new ImageIcon(getClass().getResource("SOFSJKI.png"));
        
        // Jlabel = a GUI display area for a string of text, an image, or both
        JLabel SOFS = new JLabel(); //create a label
        SOFS.setText("Spiderman Online Food Service"); //set text of label
        SOFS.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        SOFS.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        SOFS.setBounds(118,10,400,100); //x,y,width,height
        SOFS.setForeground(new Color(237,245,225));
        SOFS.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        // SOFS.setBackground(new Color(55,150,131));
        // SOFS.setOpaque(true);

        //create a logo
        JLabel logo = new JLabel();
        SOFS.setHorizontalTextPosition(JLabel.CENTER);
        SOFS.setVerticalTextPosition(JLabel.CENTER);
        logo.setBounds(77,10,100,100); //x,y,width,height
        logo.setIcon(image);
        
        //Make panel
        JPanel header = new JPanel();
        header.setBackground(new Color(55,150,131));
        header.setSize(500,100);
        //add stuff for the JPanel
        this.add(logo);
        this.add(SOFS);
        
        //---------------------------------------------------------------
        
        //buttons
        
        //signout button
        signout_button = new JButton();
        signout_button.setBounds(15,110,85,35); //x,y,width,height
        signout_button.addActionListener(this);
        signout_button.setText("SIGN OUT");
        signout_button.setFont(new Font("Helvetica",Font.BOLD,15));
        signout_button.setForeground(new Color(237,245,225));
        signout_button.setBackground(new Color(55,150,131));
        signout_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //exit button
        exit_button = new JButton();
        exit_button.setBounds(400,510,70,30); //x,y,width,height
        exit_button.addActionListener(this);
        exit_button.setText("EXIT");
        exit_button.setFont(new Font("Helvetica",Font.BOLD,13));
        exit_button.setForeground(new Color(237,245,225));
        exit_button.setBackground(new Color(55,150,131));
        exit_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));

        //manage foods button
        manage_button = new JButton();
        manage_button.setBounds(160,240,170,50); //x,y,width,height
        manage_button.addActionListener(this);
        manage_button.setText("Manage Food Items");
        manage_button.setFont(new Font("Helvetica",Font.BOLD,17));
        manage_button.setForeground(new Color(237,245,225));
        manage_button.setBackground(new Color(55,150,131));
        manage_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //view orders button
        vieworders_button = new JButton();
        vieworders_button.setBounds(160,310,170,50); //x,y,width,height
        vieworders_button.addActionListener(this);
        vieworders_button.setText("View Orders");
        vieworders_button.setFont(new Font("Helvetica",Font.BOLD,18));
        vieworders_button.setForeground(new Color(237,245,225));
        vieworders_button.setBackground(new Color(55,150,131));
        vieworders_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //more button
        profile_button = new JButton();
        profile_button.setBounds(15,510,70,30); //x,y,width,height
        profile_button.addActionListener(this);
        profile_button.setText("PROFILE");
        profile_button.setFont(new Font("Helvetica",Font.BOLD,13));
        profile_button.setForeground(new Color(237,245,225));
        profile_button.setBackground(new Color(55,150,131));
        profile_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //---------------------------------------------------------------
        
        //Jframe or window
            this.setTitle("SOFS admin/staff homepage");
            this.setSize(500,600); //sets the x-dimension, sets y dimension
            this.getContentPane().setBackground(new Color(237,245,225)); //change background color to custom (R,G,B)
            this.setResizable(false); //window not resizable
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close when exited (release RAM)
            this.setLocation(600,200);
            this.setLayout(null); //setting position
            //add stuff for the JFrame
            this.add(header);
            this.add(signout_button);
            this.add(exit_button);
            this.add(profile_button);
            this.add(manage_button);
//            this.add(modify_button);
//            this.add(foods_button);
            this.add(vieworders_button);
            this.setVisible(true);
     }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signout_button){
            new homepage();
            this.dispose();
        }else if(e.getSource() == exit_button){
            System.exit(0);
        } else if(e.getSource() == manage_button){
            new cruds();
            this.dispose();
        } else if (e.getSource() == profile_button){
            new profile();
            this.dispose();
        }else if (e.getSource() == vieworders_button){
            new view_customerorders();
            this.dispose();
        }
    }  
}

