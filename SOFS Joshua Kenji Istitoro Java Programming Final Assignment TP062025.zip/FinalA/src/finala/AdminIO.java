package finala;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class AdminIO {
        public static ArrayList<admin> AdminInfo = new ArrayList<admin>();
    public static void read(){
        try{
            Scanner s = new Scanner(new File("Admin.txt"));
            while (s.hasNext()){
                String username = s.nextLine();
                String password = s.nextLine();
//                s.nextLine(); //make another paragraph for other new users
                AdminInfo.add(new admin(username,password));
            }
        }catch (Exception e){
            System.out.println("Error! - reading ");
        }
    }
    public static void write(){
        try{
            PrintWriter a = new PrintWriter("Admin.txt");
            for(int i=0; i<AdminInfo.size(); i++){
                admin c = AdminInfo.get(i);
                a.println(c.getUsername());
                a.println(c.getPassword());
//                a.println();
            }
            a.close();

        }catch (Exception e){
            System.out.println("Error! - writting");
        }
    }
    public static admin checkAdmin(String newAdmin){
        admin found = null;
        for(int i=0; i<AdminInfo.size(); i++){
            admin c = AdminInfo.get(i);
            if(newAdmin.equals(c.getUsername())){
                found = c;
                break;
            }
        }return found;
    }
}

