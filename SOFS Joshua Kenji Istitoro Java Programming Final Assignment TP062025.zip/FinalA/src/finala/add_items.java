package finala;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class add_items extends JFrame implements ActionListener{

    JButton cancel_button;
    JTextField additem_field;
    JTextField itemprice_field;
    JComboBox itemcategory;
//    JTextField itemcategory_field;
    JButton additem_button;
    
    add_items(){
        
         // ------------------------header--------------------------------
        
        //icon
        ImageIcon image = new ImageIcon(getClass().getResource("SOFSJKI.png"));
        
        // Jlabel = a GUI display area for a string of text, an image, or both
        JLabel SOFS = new JLabel(); //create a label
        SOFS.setText("Spiderman Online Food Service"); //set text of label
        SOFS.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        SOFS.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        SOFS.setBounds(118,10,400,100); //x,y,width,height
        SOFS.setForeground(new Color(237,245,225));
        SOFS.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        // SOFS.setBackground(new Color(55,150,131));
        // SOFS.setOpaque(true);

        //create a logo
        JLabel logo = new JLabel();
        SOFS.setHorizontalTextPosition(JLabel.CENTER);
        SOFS.setVerticalTextPosition(JLabel.CENTER);
        logo.setBounds(77,10,100,100); //x,y,width,height
        logo.setIcon(image);
        
        //Make panel
        JPanel header = new JPanel();
        header.setBackground(new Color(55,150,131));
        header.setSize(500,100);
        //add stuff for the JPanel
        this.add(logo);
        this.add(SOFS);
        
        //---------------------------------------------------------------
        
        //buttons
        
        //cancel button
        cancel_button = new JButton();
        cancel_button.setBounds(15,110,85,35); //x,y,width,height
        cancel_button.addActionListener(this);
        cancel_button.setText("CANCEL");
        cancel_button.setFont(new Font("Helvetica",Font.BOLD,15));
        cancel_button.setForeground(new Color(237,245,225));
        cancel_button.setBackground(new Color(55,150,131));
        cancel_button.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //add food label
        JLabel additem_label = new JLabel(); //create a label
        additem_label.setText("Add Item:"); //set text of label
        additem_label.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        additem_label.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        additem_label.setBounds(150,120,300,100); //x,y,width,height
        additem_label.setForeground(new Color(55,150,131));
        additem_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //add item field
        additem_field = new JTextField();
        additem_field.setBounds(150, 190, 200, 30); //x,y,width,height
        
        //add price label - item
        JLabel itemprice_label  = new JLabel(); //create a label
        itemprice_label.setText("Price:"); //set text of label
        itemprice_label.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        itemprice_label.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        itemprice_label.setBounds(150,200,300,100); //x,y,width,height
        itemprice_label.setForeground(new Color(55,150,131));
        itemprice_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //add item price field
        itemprice_field = new JTextField();
        itemprice_field.setBounds(150, 270, 200, 30); //x,y,width,height
        
        //add price label - item
        JLabel itemcategory_label  = new JLabel(); //create a label
        itemcategory_label.setText("Category:"); //set text of label
        itemcategory_label.setHorizontalTextPosition(JLabel.CENTER); //set H left center right of imageicon
        itemcategory_label.setVerticalTextPosition(JLabel.CENTER); //set V left center right of imageicon
        itemcategory_label.setBounds(150,280,300,100); //x,y,width,height
        itemcategory_label.setForeground(new Color(55,150,131));
        itemcategory_label.setFont(new Font("Helvetica",Font.BOLD,20)); //set font
        
        //add item category field
//        itemcategory_field = new JTextField();
//        itemcategory_field.setBounds(150, 350, 200, 30); //x,y,width,height
            
        String[] categories = {"rice","noodle","appetizer","desert","drink"};
        itemcategory = new JComboBox(categories);
        itemcategory.setBounds(150,350,200,30);
        itemcategory.setBackground(Color.WHITE);
        
        
        // submit button - item
        additem_button = new JButton();
        additem_button.setBounds(200,400,100,40);
        additem_button.addActionListener(this);
        additem_button.setText("Add");
        additem_button.setFont(new Font("Helvetica",Font.BOLD,18));
        additem_button.setForeground(new Color(237,245,225));
        additem_button.setBackground(new Color(55,150,131));
        additem_button.setBorder(BorderFactory.createLineBorder(new Color(237,245,225)));
        
        
        //---------------------------------------------------------------
        
        //Jframe or window
        this.setTitle("SOFS add food/drinks");
        this.setSize(500,600); //sets the x-dimension, sets y dimension
        this.getContentPane().setBackground(new Color(237,245,225)); //change background color to custom (R,G,B)
        this.setResizable(false); //window not resizable
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close when exited (release RAM)
        this.setLocation(600,200);
        this.setLayout(null); //setting position
        //add stuff for the JFrame
        this.add(header);
        
        this.add(cancel_button);
        this.add(additem_label);
        this.add(additem_field);
        this.add(itemprice_label);
        this.add(itemprice_field);
        this.add(itemcategory_label);
//        this.add(itemcategory_field);
        this.add(itemcategory);
        this.add(additem_button);
        
        this.setVisible(true);
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == cancel_button){
        new homepage_admin();
        this.dispose();
        }else if (e.getSource() == additem_button){
            if(additem_field.getText()== "" || itemprice_field.getText()== "" || itemcategory.getSelectedItem().toString() == "") {
                JOptionPane.showMessageDialog(null,"Please Fill in All Fields!");
            }else{
                String item = additem_field.getText();
                double price = Double.parseDouble(itemprice_field.getText());
                String category = itemcategory.getSelectedItem().toString();
                
                //validate for redundant username
                item found = ItemIO.checkItem(item);
                if (found == null){
                    ItemIO.ItemInfo.add(new item(item,price,category));
                    ItemIO.write();
                    this.dispose();
//                    setVisible(false);
                    new add_items();
                    JOptionPane.showMessageDialog(null,"Items Added!");
                }else{
                JOptionPane.showMessageDialog(null,"Item Exists!");
                }
            }
        }
    }
    
}
