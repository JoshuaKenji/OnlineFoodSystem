package finala;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

public class cart {

    cart(){
        // create JFrame and JTable
        JFrame frame = new JFrame();
        JTable table = new JTable(); 
        
        String OrderInfo[][] = new String[0][3];
        Object[] columns = {"Food/Drinks","Price","Quantity"};
        DefaultTableModel model = new DefaultTableModel(OrderInfo,columns);
        model.setColumnIdentifiers(columns);
        
        for(int i=0; i<OrderIO.OrderInfo.size();i++){
            
            String rowData[] = new String[3];
            order found = OrderIO.OrderInfo.get(i);
            if(found.getUsername().equals(FinalA.login.getUsername())){
                String item = found.getItem();
                String price = String.valueOf(found.getPrice());
//                String category = found.category;
                String quantity = String.valueOf(found.getQuantity());
//                OrderInfo[i] = rowData;
                model.addRow(new Object[]{item,price,quantity});
            }
            
        }
        
        // create a table model and set a Column Identifiers to this model 
        
        // set the model to the table
        table.setModel(model);
        
        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(new Color(237,245,225));
        table.setForeground(new Color(55,150,131));
        Font font = new Font("Helvetica",Font.BOLD,16);
        table.setFont(font);
        table.setRowHeight(30);
   
        //sorter
        TableRowSorter sorter = new TableRowSorter(model);
        table.setRowSorter(sorter);
        
        JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(100, 50));
        table.getTableHeader().setBackground(new Color(55,150,131));
        table.getTableHeader().setForeground(new Color(237,245,225));
        Font font2 = new Font("Helvetica",Font.BOLD,18);
        table.getTableHeader().setFont(font2);
        
        
        //labels
        JLabel first_label = new JLabel(); 
        first_label.setText("Total Price (RM):");
        first_label.setForeground(new Color(55,150,131));
        first_label.setFont(new Font("Helvetica",Font.BOLD,15));
        first_label.setBounds(20, 310, 120, 25);   
        
        // Total Price     
        Double total = 0.0;
        
        for(int i=0; i<OrderIO.OrderInfo.size();i++){
//            total = 0.0;
            order found = OrderIO.OrderInfo.get(i);
            if(found.getUsername().equals(FinalA.login.getUsername())){
                Double total_row = found.getQuantity()*found.getPrice();
                total = total + total_row;
            }
        }
        
        JLabel total_price = new JLabel();
        total_price.setBounds(160, 310, 150, 25);
        total_price.setForeground(Color.BLACK);
        total_price.setFont(new Font("Helvetica",Font.BOLD,15));
        total_price.setText(total.toString());
        
        
        // Buttons

        JButton btnPay = new JButton("Continue");
        btnPay.setBounds(380, 465, 100, 25);
        btnPay.setFont(new Font("Helvetica",Font.BOLD,13));
        btnPay.setForeground(new Color(237,245,225));
        btnPay.setBackground(new Color(55,150,131));
        btnPay.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(380, 510, 100, 25);
        btnBack.setFont(new Font("Helvetica",Font.BOLD,13));
        btnBack.setForeground(new Color(237,245,225));
        btnBack.setBackground(new Color(55,150,131));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));

        //order completed button
        JButton rmvBack = new JButton("Remove");
        rmvBack.setBounds(380, 420, 100, 25);
        rmvBack.setFont(new Font("Helvetica",Font.BOLD,13));
        rmvBack.setForeground(new Color(237,245,225));
        rmvBack.setBackground(new Color(55,150,131));
        rmvBack.setBorder(BorderFactory.createLineBorder(new Color(55,150,131)));
        
        //JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 0, 500, 300);
        pane.getViewport().setBackground(new Color(237,245,225));
        frame.setTitle("SOFS view cart");
        frame.getContentPane().setBackground(new Color(237,245,225)); //change background color to custom (R,G,B)
        frame.setResizable(false);
        frame.setLocation(600,200); 
        frame.setLayout(null);
        frame.add(pane);
        
        //add text
        frame.add(first_label);
        
        // add fields
        frame.add(total_price);
    
        // add buttons
        frame.add(btnPay);
        frame.add(btnBack);
        frame.add(rmvBack);
        // create an array of objects to set the row data
        Object[] row = new Object[4];
        
        // back button
        btnBack.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent bk){
                if (bk.getSource() == btnBack){
                    new view_menu();
                    frame.dispose();
                }
            }
        });
        
        // button remove
        rmvBack.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                
                // getting index (i) of the selected row
                int i = table.getSelectedRow();
                if(i >= 0){
                    
                    // remove/"complete" a row from jtable
                    String view = table.getModel().getValueAt(i, 0).toString();

                    for (int j = 0; j < OrderIO.OrderInfo.size(); j++) {
                        order found = OrderIO.OrderInfo.get(j);
                        if (found.getItem().equals(view)) {
                            FinalA.order = found;
                        }
                    }
                    OrderIO.OrderInfo.remove(FinalA.order);
                    model.removeRow(i);
                    OrderIO.write();
                    
                } else{
                    System.out.println("Delete Error");
                }
            }
        });
        
        
        //continue button
        btnPay.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent bp){
                if (bp.getSource() == btnPay){
                    JOptionPane.showInputDialog("Enter Card Number");
                    JOptionPane.showMessageDialog(null, "Payment Confirmed, Food is otw");
//                    new view_menu();
//                    frame.dispose();
                }
            }
        });

        frame.setSize(500,600);
//        frame.setSize(900,400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
}
