package finala;
public class order {
    private String username;
    private String address;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    private String item;
    private double price;
    private String category;
    private int quantity;
    
    

    public order(String name, String jalan, String food, double money, String topic, int jumlah) {
        
        this.username = name;
        this.address = jalan;
        this.item = food;
        this.price = money;
        this.category = topic;
        this.quantity = jumlah;
    }
}
